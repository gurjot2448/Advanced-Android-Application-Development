package com.example.macstudent.test2;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity  implements View.OnClickListener {

    Button btnsearch;

    String firstname[] = {"a", "b", "c", "d", "e", "f", "g", "h", "i", "j"};
    String lastname[] = {"aa", "bb", "cc", "dd", "ee", "ff", "gg", "hh", "ii", "jj"};
    int balance[] = {120, 345, 890, 678, 890, 789, 567, 345, 789, 567};
    int limit[] = {1000, 2000, 3000, 4000, 5000, 6000, 7000, 8000, 9000, 12000};
    String email[] = {"a@yahoo.com", "b@yahoo.com", "c@yahoo.com", "d@yahoo.com", "e@yahoo.com", "f@yahoo.com",
            "g@yahoo.com", "h@yahoo.com", "e@yahoo.com", "f@yahoo.com"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    @Override
    public void onClick(View view) {

        if (view.getId() == btnsearch.getId()) {
            for (int i = 0; i <= 10; i++) {
                if (balance[i] / limit[i] < 0.8) {

                    {


                        String emailSubject = "subject";
                        String emailBody ="waring! balance is low";



                        String[] TO = {""};
                        String[] CC = {""};

                        Intent emailIntent = new Intent(Intent.ACTION_SEND);
                        emailIntent.setData(Uri.parse("mailto:"));
                        emailIntent.setType("text/plain");
                        emailIntent.putExtra(Intent.EXTRA_EMAIL,TO);
                        emailIntent.putExtra(Intent.EXTRA_CC,CC);
                        emailIntent.putExtra(Intent.EXTRA_SUBJECT,emailSubject);
                        emailIntent.putExtra(Intent.EXTRA_TEXT,emailBody);

                        try{
                            startActivity(Intent.createChooser(emailIntent,"send mail.........."));
                            finish();

                        } catch (android.content.ActivityNotFoundException ex){
                            Toast.makeText(MainActivity.this,"NO EMail Client",Toast.LENGTH_LONG).show();
                        }

////
////        emailIntent.putExtra("email", new String[]{userEmail});
////        intent.putExtra("body", new String[]{emailBody});
////
////        Intent i = new Intent(MainActivity.this, Email.class);
////      vity(i);
                    }
                    Toast.makeText(this, "Sending Email", Toast.LENGTH_LONG).show();

                }
            }
        }
    }

}